package tests;

import reports.TestNGListener;
import ie.curiositysoftware.testmodeller.TestModellerPath;
import ie.curiositysoftware.testmodeller.TestModellerSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import ie.curiositysoftware.allocation.dto.ResultMergeMethod;
import ie.curiositysoftware.allocation.dto.DataAllocationRow;
import reports.ExtentTestListener;
import ie.curiositysoftware.allocation.dto.DataAllocationResult;
import ie.curiositysoftware.allocation.engine.DataAllocation;
import utilities.testmodeller.TestModellerLogger;

//https://nomisma.cloud.testinsights.io/app/#!/model-engine/guid/6e2b44a3-0bcd-4bb6-9aee-477150eb8669
@Listeners(TestNGListener.class)
@TestModellerSuite(id = 1569, profileId = 101634)
public class Costofrawmaterialsandconsumables9FA775_DefaultProfile extends TestBase
{
    

    
    @Test  (groups= {"Cost_of_raw_materials_and_consumables9FA775","Cost_of_raw_materials_and_consumables9FA775 - Default Profile"})
    @TestModellerPath(guid = "c1c41828-a4be-414b-a072-f3353df8bf78")
    public void GoToUrlAssertUrl()
    {
        
        pages.Cost_of_raw_materials_and_consumables9FA775 _Cost_of_raw_materials_and_consumables9FA775 = new pages.Cost_of_raw_materials_and_consumables9FA775(driver);
    TestModellerLogger.SetLastNodeGuid("be38a58b-1ba6-4749-a8cd-26d0b66a71b2");
    _Cost_of_raw_materials_and_consumables9FA775.GoToUrl();
    

    TestModellerLogger.SetLastNodeGuid("84902b48-8787-4f50-8d40-17ac709f4109");
    _Cost_of_raw_materials_and_consumables9FA775.AssertUrl();
    

    }

}